## How to remove the environment variable if it is added
1. `git rm --cached .env`
2. `git commit -m "Remove .env file from version control"`
3. `git push origin review`
